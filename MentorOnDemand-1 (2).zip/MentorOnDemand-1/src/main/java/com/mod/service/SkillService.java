package com.mod.service;

import com.mod.model.Skills;

public interface SkillService {
	public void insertSkills(Skills skill);


}
